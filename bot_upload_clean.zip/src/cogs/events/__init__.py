from .cmds import CmdEvents
from .errors import Errors
from .interaction import InteractionErrors
from .logs import LogEvents
from .main import MainEvents
from .tasks import ArgonTasks
from .votes import VotesCog


async def setup(bot):
    await bot.add_cog(MainEvents(bot))
    await bot.add_cog(ArgonTasks(bot))
    await bot.add_cog(CmdEvents(bot))
    await bot.add_cog(VotesCog(bot))
    await bot.add_cog(Errors(bot))
    await bot.add_cog(InteractionErrors(bot))
    await bot.add_cog(LogEvents(bot))
