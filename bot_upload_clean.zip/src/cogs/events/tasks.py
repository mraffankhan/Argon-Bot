from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from core import Argon

from discord.ext import tasks

import config
from core import Cog


class ArgonTasks(Cog):
    def __init__(self, bot: Argon):
        self.bot = bot

        self.insert_guilds.start()

    @tasks.loop(count=1)
    async def insert_guilds(self):
        default_dashboard = '{"embed": [], "scrims": [], "tourney": [], "slotm": []}'
        query = "INSERT INTO guild_data (guild_id , prefix , embed_color , embed_footer, dashboard_access) VALUES ($1 , $2 , $3, $4, $5) ON CONFLICT DO NOTHING"
        for guild in self.bot.guilds:
            await self.bot.db.execute(query, guild.id, config.PREFIX, config.COLOR, config.FOOTER, default_dashboard)

    @insert_guilds.before_loop
    async def before_loops(self):
        await self.bot.wait_until_ready()
