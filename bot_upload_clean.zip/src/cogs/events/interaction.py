from __future__ import annotations

import typing as T

if T.TYPE_CHECKING:
    from core import Argon

import discord
from discord.app_commands import AppCommandError

from core import Cog

__all__ = ("InteractionErrors",)


class InteractionErrors(Cog):
    def __init__(self, bot: Argon):
        self.bot = bot
        self.bot.tree.interaction_check = self.global_interaction_check
        self.bot.tree.on_error = self.on_app_command_error

    async def global_interaction_check(self, interaction: discord.Interaction) -> bool:
        if not interaction.guild_id:
            await interaction.response.send_message(
                embed=discord.Embed(
                    color=discord.Color.red(),
                    description="Application commands can not be used in Private Messages.",
                ),
                ephemeral=True,
            )

            return False

        return True

    async def on_app_command_error(self, interaction: discord.Interaction, error: AppCommandError):
        if isinstance(error, discord.NotFound):
            return  # these unknown interactions are annoying :pain:

        # rest later
