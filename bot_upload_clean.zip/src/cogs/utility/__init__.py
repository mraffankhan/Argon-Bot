from __future__ import annotations

import typing

from discord.utils import escape_markdown, escape_mentions

from cogs.utility.events import AutoPurgeEvents, ReminderEvents

if typing.TYPE_CHECKING:
    from core import Argon

from ast import literal_eval as leval
from contextlib import suppress
from datetime import timedelta
from io import BytesIO

import discord
from discord.ext import commands
from humanize import precisedelta

from core import Cog, Context, embeds
from models import ArrayAppend, ArrayRemove, AutoPurge, Autorole, Snipe, Tag
from utils import (
    ArgonCategory,
    ArgonMember,
    ArgonPaginator,
    ArgonRole,
    ArgonTextChannel,
    TimeText,
    checks,
    discord_timestamp,
    plural,
    simple_convert,
    strtime,
    truncate_string,
)

from .functions import TagConverter, TagName, guild_tag_stats, increment_usage, is_valid_name, member_tag_stats
from .views import *


class Utility(Cog, name="utility"):
    def __init__(self, bot: Argon):
        self.bot = bot

    @commands.group(aliases=("timer", "remind"), invoke_without_command=True)
    async def reminder(self, ctx: Context, *, when: TimeText(commands.clean_content)):  # noqa: F722
        """Reminds you of something after a certain amount of time.

        The input can be any direct date (e.g. YYYY-MM-DD) or a human
        readable offset. Examples:

        - "next thursday at 3pm do something funny"
        - "do the dishes tomorrow"
        - "in 3 days do the thing"
        - "2d unmute someone"

        """
        expire = when.dt

        if not expire:
            return await ctx.error(
                "I couldn't find time in your input. \n\nTry it like: `qremind me at 9pm to get laid.`"
            )

        await self.bot.reminders.create_timer(
            expire,
            "reminder",
            ctx.author.id,
            ctx.channel.id,
            when.arg,
            message_id=ctx.message.id,
        )

        await ctx.send(f"Alright **{ctx.author}**, I'll remind you {discord_timestamp(expire)}: {when.arg}")

    @reminder.command(name="all", ignore_extra=False)
    async def reminder_list(self, ctx: Context):
        """Shows the 10 latest currently running reminders."""
        query = """SELECT id, expires, extra #>> '{args,2}'
                   FROM timer
                   WHERE event = 'reminder'
                   AND extra #>> '{args,0}' = $1
                   ORDER BY expires;
                """

        records = await ctx.db.fetch(query, str(ctx.author.id))

        if not records:
            return await ctx.error("No currently running reminders.")

        paginator = ArgonPaginator(ctx, title=f"Total Reminders: {len(records)}", per_page=10)

        for _id, expires, message in records:
            paginator.add_line(f"`{_id}`: {truncate_string(message,40)}({discord_timestamp(expires)})")

        await paginator.start()

    @commands.group(invoke_without_command=True)
    @checks.is_mod()
    async def autorole(self, ctx: Context, off: typing.Optional[str]):
        """
        Manage Argon's autoroles.
        """
        if not off or off.lower() != "off":
            return await ctx.send_help(ctx.command)

        record = await Autorole.get_or_none(guild_id=ctx.guild.id)

        if not record:
            return await ctx.send(
                f"You have not set any autorole yet.\n\nDo it like: `{ctx.prefix}autorole humans @role`"
            )

        if not any([len(record.humans), len(record.bots)]):
            return await ctx.error("Autoroles already OFF!")
        prompt = await ctx.prompt("Are you sure you want to turn off autorole?")
        if prompt:
            # await Autorole.filter(guild_id=ctx.guild.id).update(humans=list, bots=list)
            await ctx.db.execute("UPDATE autoroles SET humans = '{}' , bots = '{}' WHERE guild_id = $1", ctx.guild.id)
            await ctx.success("Autoroles turned OFF!")
        else:
            await ctx.success("OK!")

    @autorole.command(name="humans")
    @checks.is_mod()
    @commands.bot_has_guild_permissions(manage_roles=True)
    async def autorole_humans(self, ctx: Context, *, role: ArgonRole):
        """
        Add/ Remove a role to human autoroles.
        """
        record = await Autorole.get_or_none(pk=ctx.guild.id)
        if record is None:
            await Autorole.create(guild_id=ctx.guild.id, humans=[role.id])
            text = f"Added {role.mention} to human autoroles."

        else:
            if role.id in record.humans:
                record.humans.remove(role.id)
                action = "Removed"
            else:
                record.humans.append(role.id)
                action = "Added"
            await record.save(update_fields=["humans"])
            text = f"{action} {role.mention} to human autoroles."

        await ctx.success(text)

    @autorole.command(name="bots")
    @checks.is_mod()
    @commands.bot_has_guild_permissions(manage_roles=True)
    async def autorole_bots(self, ctx: Context, *, role: ArgonRole):
        """
        Add/ Remove a role to bot autoroles.
        """
        record = await Autorole.get_or_none(pk=ctx.guild.id)
        if record is None:
            await Autorole.create(guild_id=ctx.guild.id, bots=[role.id])
            text = f"Added {role.mention} to bot autoroles."

        else:
            if role.id in record.bots:
                record.bots.remove(role.id)
                action = "Removed"
            else:
                record.bots.append(role.id)
                action = "Added"
            await record.save(update_fields=["bots"])
            text = f"{action} {role.mention} to bot autoroles."

        await ctx.success(text)

    @autorole.command(name="config")
    @checks.is_mod()
    @commands.bot_has_guild_permissions(manage_roles=True)
    async def autorole_config(self, ctx: Context):
        """
        Get autorole config
        """
        record = await Autorole.get_or_none(pk=ctx.guild.id)
        if not record:
            return await ctx.send(
                f"You have not set any autorole yet.\n\nDo it like: `{ctx.prefix}autorole humans @role`"
            )

        humans = ", ".join(record.human_roles) if list(record.human_roles) else "Not Set!"
        bots = ", ".join(record.bot_roles) if list(record.bot_roles) else "Not Set!"

        embed = self.bot.embed(ctx, title="Autorole Config")
        embed.add_field(name="Humans", value=humans, inline=False)
        embed.add_field(name="Bots", value=bots, inline=False)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="embed")
    @commands.has_permissions(manage_messages=True)
    async def embed_send(self, ctx: Context, channel: discord.TextChannel):
        """
        Generate and send embed to specified channel.
        """
        if not channel.permissions_for(ctx.me).embed_links:
            return await ctx.error(f"I need `embed_links` permission in {channel.mention}")

        view = embeds.EmbedBuilder(ctx, items=[EmbedSend(channel), EmbedCancel()])
        await view.rendor()

    @commands.hybrid_command(name="quickembed", aliases=["qe"])
    @commands.has_permissions(manage_messages=True, embed_links=True)
    @commands.bot_has_permissions(manage_messages=True, embed_links=True)
    async def quick_embed_command(self, ctx: Context, *, text: str):
        """
        Generates quick embeds.
        Tip: You can send hyperlinks too. Example: `[anytext](any link)`
        """
        embed = self.bot.embed(ctx, description=text)
        if ctx.message.attachments and "image" in ctx.message.attachments[0].content_type:
            embed.set_image(url=ctx.message.attachments[0].proxy_url)
        await ctx.send(embed=embed)
        await ctx.message.delete()

    @commands.command()
    @commands.bot_has_permissions(embed_links=True)
    async def snipe(self, ctx: Context, *, channel: typing.Optional[ArgonTextChannel]):
        """Snipe last deleted message of a channel."""

        channel = channel or ctx.channel

        snipe = await Snipe.get_or_none(channel_id=channel.id)
        if not snipe:
            return await ctx.error("There's nothing to snipe :c")

        elif snipe.nsfw and not ctx.channel.is_nsfw():
            return await ctx.error("The snipe is marked NSFW but the current channel isn't.")

        embed = self.bot.embed(ctx, timestamp=snipe.delete_time)
        embed.description = (
            f"Message sent by **{snipe.author}** was deleted in **{channel}** \n{discord_timestamp(snipe.delete_time)}\n"
            f"\n**__Message Content__**\n{snipe.content}"
        )

        embed.set_footer(text="Deleted")
        await ctx.send(embed=embed)

    @commands.group(invoke_without_command=True)
    async def tag(self, ctx: Context, *, name: typing.Optional[TagConverter]):
        """Call a tag with its name or id"""
        if name is None:
            return await ctx.send_help(ctx.command)

        if name.is_nsfw and not ctx.channel.is_nsfw():
            return await ctx.error("This tag can only be used in NSFW channels.")

        if name.is_embed is True:
            _dict = leval(name.content)
            await ctx.send(embed=discord.Embed.from_dict(_dict), reference=ctx.replied_reference)

        if not name.content:
            return await ctx.error("Tag doesn't have any content")
        await ctx.send(name.content, reference=ctx.replied_reference)
        await increment_usage(ctx, name.name)

    @tag.command(name="raw")
    @commands.bot_has_permissions(attach_files=True)
    async def raw_tag_content(self, ctx: Context, *, name: TagConverter):
        """Get the raw content of the tag"""
        if name.is_nsfw and not ctx.channel.is_nsfw():
            return await ctx.error("This tag can only be used in NSFW channels.")
        if not name.content:
            return await ctx.error("Tag does not have any content")
        temp = escape_markdown(name.content).replace("<", "\\<")  # why not!?
        main = escape_mentions(temp)
        if len(main) > 1990:  # for some reason exact `2000` do not work...
            file_obj = BytesIO(main.encode())
            return await ctx.send(file=discord.File(file_obj, filename="message_too_long.txt"))
        await ctx.send(main, allowed_mentions=discord.AllowedMentions.none())

    @tag.command(name="all", aliases=("list",))
    async def all_tags(self, ctx: Context, *, member: typing.Optional[ArgonMember]):
        """Get all tags owned by the server or a member"""
        if not member:
            tags = await Tag.filter(guild_id=ctx.guild.id)

            if not tags:
                return await ctx.error("This server doesn't have any tags.")

        else:
            tags = await Tag.filter(guild_id=ctx.guild.id, owner_id=member.id)
            if not tags:
                return await ctx.error(f"{member} doesn't own any tag.")

        paginator = ArgonPaginator(ctx, title=f"Total Tags: {len(tags)}", per_page=12)

        for idx, tag in enumerate(tags, start=1):
            paginator.add_line(f"`{idx:02}` {escape_markdown(tag.name)} (ID: {tag.id})")

        await paginator.start()

    @tag.command(name="info")
    async def tag_info(self, ctx: Context, *, tag: TagConverter):
        """Information about a tag"""
        embed = self.bot.embed(ctx, title=f"Stats for tag {tag.name}")

        user = self.bot.get_user(tag.owner_id) or await self.bot.fetch_user(tag.owner_id)

        embed.set_author(name=str(user), icon_url=user.display_avatar.url)

        embed.add_field(name="Owner", value=getattr(user, "mention", "Invalid User!"))
        embed.add_field(name="ID:", value=tag.id)
        embed.add_field(name="Uses", value=tag.usage)
        embed.add_field(name="NSFW", value="Yes" if tag.is_nsfw else "No")
        embed.add_field(name="Embed", value="Yes" if tag.is_embed else "No")
        embed.set_footer(text=f"Created At: {strtime(tag.created_at)}")
        await ctx.send(embed=embed)

    @tag.command(name="claim")
    async def claim_tag(self, ctx: Context, *, tag: TagConverter):
        """Claims a tag if the original owner left the server."""
        member = await self.bot.get_or_fetch_member(ctx.guild, tag.owner_id)

        if member is not None:
            return await ctx.send(f"The owner of this tag ({tag.owner}) is still in the server.")

        await Tag.filter(name=tag.name, guild_id=ctx.guild.id).update(owner_id=ctx.author.id)
        await ctx.success("Transfered tag ownership to you.")

    @tag.command(name="create")
    async def create_tag_command(self, ctx: Context, name: TagName, *, content: typing.Optional[str] = ""):
        """Create a new tag"""
        if content == "" and not ctx.message.attachments:
            return await ctx.error("Cannot make an empty tag.")

        if ctx.message.attachments:
            content += f"\n{ctx.message.attachments[0].proxy_url}"

        if len(content) > 1990:
            return await ctx.error("Tag content cannot contain more than 1990 characters.")

        if len(name) > 99:
            return await ctx.error("Tag Name cannot contain more that 99 characters.")

        if await is_valid_name(ctx, name):
            tag = await Tag.create(name=name, content=content, guild_id=ctx.guild.id, owner_id=ctx.author.id)

            await ctx.success(f"Created Tag (ID: `{tag.id}`)")

        else:
            await ctx.error("Tag Name is already taken.")

    @tag.command(name="delete", aliases=["del"])
    async def delete_tag(self, ctx: Context, *, tag: TagConverter):
        """Delete a tag"""
        tag = tag
        if tag.owner_id != ctx.author.id and not ctx.author.guild_permissions.manage_guild:
            return await ctx.error("This tag doesn't belong to you.")

        await Tag.filter(guild_id=ctx.guild.id, name=tag.name, owner_id=tag.owner_id).delete()
        await ctx.success(f"Deleted {tag.name}")

    @tag.command(name="transfer")
    async def transfer_tag(self, ctx: Context, member: ArgonMember, *, tag: TagConverter):
        """Transfer the ownership of a tag."""
        if tag.owner_id != ctx.author.id:
            return await ctx.error("This tag doesn't belong to you.")

        await Tag.filter(id=tag.id).update(owner_id=member.id)
        await ctx.success("Transfer successful.")

    @tag.command("nsfw")
    async def nsfw_status_toggle(self, ctx: Context, *, tag: TagConverter):
        """Toggle NSFW for a tag."""
        if tag.owner_id != ctx.author.id and not ctx.author.guild_permissions.manage_guild:
            return await ctx.error("This tag doesn't belong to you.")

        await Tag.filter(id=tag.id).update(is_nsfw=not tag.is_nsfw)
        await ctx.success(f"Tag NSFW toggled {'ON' if not tag.is_nsfw else 'OFF'}!")

    @tag.command("mine")
    async def get_all_tags(self, ctx: Context):
        """Get a list of all tags owned by you."""
        tags = await Tag.filter(guild_id=ctx.guild.id, owner_id=ctx.author.id)

        if not tags:
            return await ctx.error("You do not own any tag.")

        paginator = ArgonPaginator(ctx, title=f"Tags you own: {len(tags)}", per_page=12)

        for idx, tag in enumerate(tags, start=1):
            paginator.add_line(f"`{idx:02}` {escape_markdown(tag.name)} (ID: {tag.id})")

        await paginator.start()

    @tag.command(name="purge")
    @commands.has_guild_permissions(manage_guild=True)
    async def purge_tags(self, ctx: Context, *, member: ArgonMember):
        """Delete all the tags of a member"""
        count = await Tag.filter(owner_id=member.id, guild_id=ctx.guild.id).count()
        if not count:
            return await ctx.error(f"{member} doesn't own any tag.")

        await Tag.filter(owner_id=member.id, guild_id=ctx.guild.id).delete()
        await ctx.success(f"Deleted {plural(count): tag|tags} of **{member}**.")

    @tag.command(name="edit")
    async def edit_tag(self, ctx: Context, name: TagName, *, content: typing.Optional[str] = ""):
        """Edit a tag"""
        tag = await Tag.get_or_none(name=name, guild_id=ctx.guild.id)
        if not tag:
            return await ctx.error("Tag name is invalid.")

        if tag.owner_id != ctx.author.id and not ctx.author.guild_permissions.manage_guild:
            return await ctx.error("This tag doesn't belong to you.")

        if len(content) > 1990:
            return await ctx.error("Tag content cannot exceed 1990 characters.")

        if content == "" and not ctx.message.attachments:
            return await ctx.error("Cannot edit tag.")

        if ctx.message.attachments:
            content += f"\n{ctx.message.attachments[0].proxy_url}"

        await Tag.filter(id=tag.id).update(content=content)
        await ctx.success("Tag updated.")

    # @tag.command(name="make")
    # async def tag_make(self, ctx: Context):
    #     """Make tags interactively."""

    #     def check(message: discord.Message):
    #         if message.content.strip().lower() == "cancel":
    #             raise commands.BadArgument("Alright, reverting all process.")

    #         return message.author == ctx.author and ctx.channel == message.channel

    #     msg = await ctx.simple("What do you want the tag name to be?")
    #     name = await inputs.string_input(ctx, check, delete_after=True)
    #     await inputs.safe_delete(msg)

    #     embed = await ctx.simple(
    #         f"What do you want the content to be?\n\n{keycap_digit(1)} | Simple Text\n{keycap_digit(2)} | Embed"
    #     )
    #     reactions = [keycap_digit(1), keycap_digit(2)]
    #     for reaction in reactions:
    #         await embed.add_reaction(reaction)

    @tag.command(name="search")
    async def search_tag(self, ctx: Context, *, name: str):
        """Search in all your tags."""
        tags = await Tag.filter(guild_id=ctx.guild.id, name__icontains=name)

        if not tags:
            return await ctx.error("No tags found.")

        paginator = ArgonPaginator(ctx, title=f"Matching Tags: {len(tags)}", per_page=10)
        for idx, tag in enumerate(tags, start=1):
            paginator.add_line(f"`{idx:02}` {tag.name} (ID: {tag.id})")

        await paginator.start()

    @tag.command(name="stats")
    async def tag_stats(self, ctx: Context, *, member: typing.Optional[ArgonMember]):
        """Tag statistics of the server or a member."""
        if member:
            await member_tag_stats(ctx, member)
        else:
            await guild_tag_stats(ctx)

    @commands.group(invoke_without_command=True)
    async def category(self, ctx: Context):
        """hide , delete , unhide or even nuke a category"""
        await ctx.send_help(ctx.command)

    @category.command(name="delete")
    @commands.has_permissions(manage_channels=True, manage_guild=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def category_delete(self, ctx: Context, *, category: ArgonCategory):
        """Delete a category and all the channels under it."""
        if not category.channels:
            return await ctx.error(f"**{category}** doesn't have any channels.")

        prompt = await ctx.prompt(
            message=f"All channels under the category `{category}` will be deleted.\nAre you sure you want to continue?"
        )
        if prompt:
            failed, success = 0, 0

            for channel in category.channels:
                try:
                    await channel.delete()
                    success += 1
                except discord.HTTPException:
                    failed += 1
                    continue

            await category.delete()

            with suppress(
                discord.Forbidden, commands.ChannelNotFound, discord.NotFound, commands.CommandInvokeError
            ):  # yes all these will be raised if the channel is from ones we deleted earlier.
                await ctx.success(f"Successfully deleted **{category}**. (Deleted: `{success}`, Failed: `{failed}`)")

        else:
            await ctx.simple("Ok Aborting.")

    @category.command(name="hide")
    @commands.has_permissions(manage_channels=True, manage_guild=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def category_hide(self, ctx: Context, *, category: ArgonCategory):
        """Hide a category and all its channels"""
        if not category.channels:
            return await ctx.error(f"**{category}** doesn't have any channels.")

        prompt = await ctx.prompt(
            message=f"All channels under the category `{category}` will be hidden.\nAre you sure you want to continue?"
        )
        if prompt:
            failed, success = 0, 0

            for channel in category.channels:
                try:
                    perms = channel.overwrites_for(ctx.guild.default_role)
                    perms.read_messages = False
                    await channel.set_permissions(ctx.guild.default_role, overwrite=perms)
                    success += 1
                except discord.HTTPException:
                    failed += 1
                    continue

            await ctx.success(f"Successfully hidden category. (Hidden: `{success}`, Failed: `{failed}`)")

        else:
            await ctx.simple("Ok Aborting.")

    @category.command(name="unhide")
    @commands.has_permissions(manage_channels=True, manage_guild=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def category_unhide(self, ctx: Context, *, category: ArgonCategory):
        """Unhide a hidden category and all its channels."""
        if not category.channels:
            return await ctx.error(f"**{category}** doesn't have any channels.")

        prompt = await ctx.prompt(
            message=f"All channels under the category `{category}` will be unhidden.\nAre you sure you want to continue?"
        )
        if prompt:
            failed, success = 0, 0

            for channel in category.channels:
                try:
                    perms = channel.overwrites_for(ctx.guild.default_role)
                    perms.read_messages = True
                    await channel.set_permissions(ctx.guild.default_role, overwrite=perms)
                    success += 1
                except discord.HTTPException:
                    failed += 1
                    continue

            await ctx.success(f"Successfully unhidden **{category}**. (Unhidden: `{success}`, Failed: `{failed}`)")

        else:
            await ctx.simple("Ok Aborting.")

    @category.command(name="nuke")
    @commands.has_permissions(manage_channels=True, manage_guild=True)
    @commands.bot_has_permissions(manage_channels=True)
    async def category_nuke(self, ctx: Context, *, category: ArgonCategory):
        """
        Delete a category completely and create a new one
        This will delete all the channels under the category and will make a new one with same perms and channels.
        """
        if not category.channels:
            return await ctx.error(f"**{category}** doesn't have any channels.")

        prompt = await ctx.prompt(
            message=f"All channels under the category `{category}` will be cloned and deleted.\nAre you sure you want to continue?"
        )
        if prompt:
            failed, success = 0, 0
            for channel in category.channels:
                if channel.permissions_for(ctx.me).manage_channels:
                    try:
                        position = channel.position
                        clone = await channel.clone(reason=f"Action done by {ctx.author}")
                        await channel.delete()
                        await clone.edit(position=position)
                        success += 1
                    except discord.HTTPException:
                        failed += 1
                        continue

            await ctx.success(f"Successfully nuked **{category}**. (Cloned: `{success}`, Failed: `{failed}`)")

        else:
            await ctx.simple("Ok Aborting.")

    @commands.group(invoke_without_command=True)
    async def autopurge(self, ctx: Context):
        """
        Set Argon to delete every new message in a channel after  a specific interval.
        """
        await ctx.send_help(ctx.command)

    @autopurge.command(name="set")
    @commands.has_permissions(manage_messages=True)
    async def autopurge_set(self, ctx: Context, channel: ArgonTextChannel, delete_after: str):
        """
        Set the autopurge for a channel
        `delete_after` should be in this format: s|m|h|d
        """
        if not channel.permissions_for(ctx.me).manage_messages:
            return await ctx.error("I don't have `manage messages` permission in {0}".format(channel.mention))

        seconds = simple_convert(delete_after)

        if seconds <= 5 or seconds > 604800:
            return await ctx.error("Delete Time must be more than 5s and less than 7d.")

        if (count := await AutoPurge.filter(guild_id=ctx.guild.id).count()) >= 1 and not await ctx.is_premium_guild():
            return await ctx.error(
                "You cannot set autopurge in more than 1 channel in free tier."
                f"\nHowever [Argon Premium]({ctx.bot.prime_link}) allows you to set autopurge in unlimited channels."
            )

        if channel.id in self.bot.cache.autopurge_channels:
            return await ctx.error(f"**{channel}** is already an autopurge channel.")

        await AutoPurge.create(guild_id=ctx.guild.id, channel_id=channel.id, delete_after=seconds)
        self.bot.cache.autopurge_channels.add(channel.id)
        await ctx.success(f"**{channel}** added to autopurge channels.")

    @autopurge.command(name="list")
    @commands.has_permissions(manage_messages=True)
    async def autopurge_config(self, ctx: Context):
        """Get a list of all autopurge channels"""
        records = await AutoPurge.filter(guild_id=ctx.guild.id)
        if not records:
            return await ctx.error("This server doesn't have any autopurge channels.")

        text = "".join(
            f"`{idx:02}` | {getattr(record.channel, 'mention', 'Deleted Channel')} ({precisedelta(timedelta(seconds=record.delete_after))})\n"
            for idx, record in enumerate(records, start=1)
        )
        await ctx.send(embed=self.bot.embed(ctx, description=text, title="AutoPurge List"), embed_perms=True)

    @autopurge.command(name="remove")
    @commands.has_permissions(manage_messages=True)
    async def autopurge_remove(self, ctx: Context, *, channel: ArgonTextChannel):
        """Remove a channel from autopurge"""
        if channel.id not in self.bot.cache.autopurge_channels:
            return await ctx.error(f"{channel} is not an autopurge channel.")

        self.bot.cache.autopurge_channels.discard(channel.id)
        await AutoPurge.filter(channel_id=channel.id, guild_id=ctx.guild.id).delete()
        await ctx.success(f"**{channel}** removed from autopurge channels.")

    @commands.hybrid_command(name="serverinfo", aliases=["si", "server"])
    @commands.guild_only()
    async def serverinfo(self, ctx: Context):
        """Get detailed information about the current server."""
        guild = ctx.guild
        
        # Determine features
        features = []
        for feature in guild.features:
            features.append(f"✅ : {feature.replace('_', ' ').title()}")
        if not features:
            features_text = "None"
        else:
            features_text = "\n".join(features)
            
        # Channel counts
        categories = len(guild.categories)
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        threads = len(guild.threads)
        
        locked_text = sum(1 for c in guild.text_channels if c.overwrites_for(guild.default_role).send_messages is False)
        hidden_text = sum(1 for c in guild.text_channels if c.overwrites_for(guild.default_role).view_channel is False)
        
        locked_voice = sum(1 for c in guild.voice_channels if c.overwrites_for(guild.default_role).connect is False)
        hidden_voice = sum(1 for c in guild.voice_channels if c.overwrites_for(guild.default_role).view_channel is False)

        bots = sum(1 for m in guild.members if m.bot)
        humans = guild.member_count - bots
        
        embed = self.bot.embed(ctx, title=f"{guild.name}'s Information")
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
            
        owner = guild.owner
        if not owner and guild.owner_id:
            try:
                owner = await self.bot.fetch_user(guild.owner_id)
            except discord.HTTPException:
                pass
                
        owner_text = f"{owner.mention} (@{owner.name})" if owner else "Unknown"
        
        # About
        embed.add_field(
            name="About",
            value=f"**Name :** {guild.name}\n"
            f"**ID :** {guild.id}\n"
            f"**Owner :** 👑 : {owner_text}\n"
            f"**Created At :** {guild.created_at.strftime('%A, %B %d, %Y %I:%M %p')}\n"
            f"**Members :** {guild.member_count}",
            inline=False
        )
        
        # Description
        embed.add_field(
            name="Description",
            value=guild.description or "None",
            inline=False
        )
        
        # Features
        if features_text != "None":
            embed.add_field(
                name="Features",
                value=features_text,
                inline=False
            )
            
        # Extras
        embed.add_field(
            name="Extras",
            value=f"**Verification Level :** {str(guild.verification_level).title()}\n"
            f"**AFK Channel :** {guild.afk_channel.name if guild.afk_channel else 'None'}\n"
            f"**AFK Timeout :** {guild.afk_timeout / 60.0}\n"
            f"**System Channel :** {guild.system_channel.name if guild.system_channel else 'None'}\n"
            f"**NSFW level :** {str(guild.nsfw_level).replace('NSFWLevel.', '').title()}\n"
            f"**Explicit Content Filter :** {str(guild.explicit_content_filter).title()}\n"
            f"**Max Talk Bitrate :** {int(guild.bitrate_limit / 1000)} kbps",
            inline=False
        )
        
        # Members
        embed.add_field(
            name="Members",
            value=f"**Members :** {guild.member_count}\n"
            f"**Humans :** {humans}\n"
            f"**Bots :** {bots}",
            inline=True
        )
        
        # Channels
        embed.add_field(
            name="Channels",
            value=f"**Categories :** {categories}\n"
            f"**Text Channels :** {text_channels} (Locked: {locked_text}, Hidden: {hidden_text})\n"
            f"**Voice Channels :** {voice_channels} (Locked: {locked_voice}, Hidden: {hidden_voice})\n"
            f"**Threads :** {threads}",
            inline=True
        )
        
        # Emoji Info
        regular_emojis = len([e for e in guild.emojis if not e.animated])
        embed.add_field(
            name="Emoji Info",
            value=f"**Regular Emojis :** {regular_emojis}\n"
            f"**Stickers :** {len(guild.stickers)}\n"
            f"**Total Emoji/Stickers :** {len(guild.emojis) + len(guild.stickers)}",
            inline=True
        )
        
        # Boost Status
        embed.add_field(
            name="Boost Status",
            value=f"**Level :** {guild.premium_tier} [<:02boost:1255554605992017990> {guild.premium_subscription_count} Boosts]\n"
            f"**Booster Role :** {guild.premium_subscriber_role.mention if guild.premium_subscriber_role else 'None'}",
            inline=False
        )
        
        # Server Roles
        roles = [role.mention for role in reversed(guild.roles) if role.name != "@everyone"]
        roles_text = " • ".join(roles) if roles else "None"
        if len(roles_text) > 1024:
            roles_text = roles_text[:1020] + "..."
            
        embed.add_field(
            name=f"Server Roles [ {len(roles)} ]",
            value=roles_text,
            inline=False
        )
        
        embed.set_author(name=f"Requested By {ctx.author}", icon_url=ctx.author.display_avatar.url)
        await ctx.send(embed=embed)


async def setup(bot: Argon) -> None:
    await bot.add_cog(Utility(bot))
    await bot.add_cog(AutoPurgeEvents(bot))
    await bot.add_cog(ReminderEvents(bot))
