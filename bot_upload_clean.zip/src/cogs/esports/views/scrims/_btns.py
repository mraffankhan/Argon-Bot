from __future__ import annotations

from datetime import timedelta

import discord
from discord import Interaction

from core import Context
from models import Scrim
from utils import discord_timestamp as dt
from utils import emote, inputs
from utils import regional_indicator as ri
from utils import truncate_string

from ._base import ScrimsButton


class ScrimNameModal(discord.ui.Modal, title="Scrim Name"):
    name_input = discord.ui.TextInput(
        label="Scrim Name",
        placeholder="Enter the new name of this scrim...",
        style=discord.TextStyle.short,
        required=True,
        max_length=30,
    )

    def __init__(self, view):
        super().__init__()
        self.scrim_view = view

    async def on_submit(self, interaction: Interaction):
        await interaction.response.defer()
        self.scrim_view.record.name = self.name_input.value
        await self.scrim_view.refresh_view()


class SetName(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        # Do NOT defer here because we need to send a modal!
        await interaction.response.send_modal(ScrimNameModal(self.view))


class RegChannel(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        m = await self.ctx.simple("Mention the channel where you want to take registrations.")
        channel = await inputs.channel_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        if await Scrim.filter(registration_channel_id=channel.id).exists():
            return await self.ctx.error("That channel is already in use for another scrim.", 5)

        self.view.record.registration_channel_id = channel.id

        if not self.view.record.slotlist_channel_id:
            self.view.record.slotlist_channel_id = channel.id

        await self.view.refresh_view()


class SlotChannel(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("Mention the channel where you want me to post slotlist after registrations.")
        channel = await inputs.channel_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        self.view.record.slotlist_channel_id = channel.id

        await self.view.refresh_view()


class SetRole(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        m = await self.ctx.simple("Mention the role you want to give for correct registration.")
        role = await inputs.role_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        self.view.record.role_id = role.id

        await self.view.refresh_view()


class SetMentions(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        m = await self.ctx.simple("How many mentions are required for registration? (Max `10`)")
        self.view.record.required_mentions = await inputs.integer_input(self.ctx, delete_after=True, limits=(0, 10))
        await self.ctx.safe_delete(m)

        await self.view.refresh_view()


class MinLines(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        if not await self.ctx.is_premium_guild():
            return await self.ctx.error(
                "**Argon Premium is required to use this feature.**\n\n`Use qpro command to activate Premium.`", 5
            )

        m = await self.ctx.simple("How many lines in registration message are required for registration? (Max `100`)")
        self.view.record.required_lines = await inputs.integer_input(self.ctx, delete_after=True, limits=(0, 10))
        await self.ctx.safe_delete(m)

        await self.view.refresh_view()


class DuplicateTags(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))

        self.ctx = ctx

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer()

        if not await self.ctx.is_premium_guild():
            return await self.ctx.error(
                "[Argon Premium](https://ravonixx.xyz/premium) is required to use this feature.", 4
            )

        self.view.record.allow_duplicate_tags = not self.view.record.allow_duplicate_tags
        await self.ctx.success(
            f"Registrations with fake / duplicate mentions are now **{'allowed' if self.view.record.allow_duplicate_tags else 'not allowed'}**.",
            3,
        )
        await self.view.refresh_view()
        await self.view.record.confirm_all_scrims(self.ctx, allow_duplicate_tags=self.view.record.allow_duplicate_tags)


class TotalSlots(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        m = await self.ctx.simple("How many total slots are there? (Max `30`)")
        self.view.record.total_slots = await inputs.integer_input(self.ctx, delete_after=True, limits=(1, 30))
        await self.ctx.safe_delete(m)

        await self.view.refresh_view()


class OpenTime(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        m = await self.ctx.simple(
            "At what time do you want me to open registrations daily?\n\nTime examples:",
            image="https://cdn.discordapp.com/attachments/851846932593770496/958291942062587934/timex.gif",
            footer="Time is according to Indian Standard Time (UTC+05:30)",
        )
        self.view.record.open_time = await inputs.time_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)

        await self.view.refresh_view()


class SetEmojis(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        if not await self.ctx.is_premium_guild():
            return await self.ctx.error(
                "[Argon Premium](https://ravonixx.xyz/premium) is required to use this feature.", 4
            )

        e = discord.Embed(color=self.ctx.bot.color, title="Edit scrims emojis")

        e.description = (
            "Which emojis do you want to use for tick and cross in scrims registrations?\n\n"
            "`Please enter two emojis and separate them with a comma`"
        )

        e.set_image(url="https://cdn.discordapp.com/attachments/851846932593770496/888097255607906354/unknown.png")
        e.set_footer(text="The first emoji must be the emoji for tick mark.")

        m = await interaction.followup.send(embed=e)
        emojis = await inputs.string_input(self.ctx, delete_after=True)

        await self.ctx.safe_delete(m)

        emojis = emojis.strip().split(",")
        if not len(emojis) == 2:
            return await interaction.followup.send("You didn't enter the correct format.", ephemeral=True)

        check, cross = emojis

        for emoji in emojis:
            try:
                await self.view.message.add_reaction(emoji.strip())
                await self.view.message.clear_reactions()
            except discord.HTTPException:
                return await interaction.followup.send("One of the emojis you entered is invalid.", ephemeral=True)

        self.view.record.emojis = {"tick": check.strip(), "cross": cross.strip()}
        await self.view.refresh_view()
        await self.view.record.confirm_all_scrims(self.ctx, emojis=self.view.record.emojis)


class SetAutoclean(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        from ._ac import AutocleanView

        self.view.stop()

        view = AutocleanView(self.ctx, self.view.record)
        await view._add_buttons()
        view.message = await self.view.message.edit(embed=await view.initial_embed, view=view)


class PingRole(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        if self.view.record.ping_role_id:
            self.view.record.ping_role_id = None
            await self.view.refresh_view()
            return await self.ctx.success("Removed ping-role, click again to set.", 5)

        m = await self.ctx.simple("Mention the role you want to ping when registration starts.")
        role = await inputs.role_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)
        self.view.record.ping_role_id = role.id
        await self.view.refresh_view()


class OpenRole(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        m = await self.ctx.simple("Mention the role you want to open registration for.")
        role = await inputs.role_input(self.ctx, delete_after=True)
        await self.ctx.safe_delete(m)
        self.view.record.open_role_id = role.id
        await self.view.refresh_view()


class OpenDays(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        from ._days import WeekDays

        await interaction.response.defer()
        v = discord.ui.View(timeout=60.0)
        v.add_item(WeekDays())

        await interaction.followup.send("Please select the days to open registrations:", view=v, ephemeral=True)
        await v.wait()
        if c := getattr(v, "custom_id", None):
            self.view.record.open_days = c
            await self.view.refresh_view()


class MultiReg(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        self.view.record.multiregister = not self.view.record.multiregister
        await self.ctx.success(
            f"Now users **{'can' if self.view.record.multiregister else 'can not'}** register more than once.", 3
        )
        await self.view.refresh_view()

        await self.view.record.confirm_all_scrims(self.ctx, multiregister=self.view.record.multiregister)


class TeamCompulsion(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        self.view.record.teamname_compulsion = not self.view.record.teamname_compulsion
        await self.ctx.success(
            f"Now Team Name **{'is' if self.view.record.teamname_compulsion else 'is not'}** required to register.", 3
        )
        await self.view.refresh_view()
        await self.view.record.confirm_all_scrims(self.ctx, teamname_compulsion=self.view.record.teamname_compulsion)


class DuplicateTeam(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        self.view.record.no_duplicate_name = not self.view.record.no_duplicate_name
        await self.ctx.success(
            f"Duplicate team names are now **{'not allowed' if self.view.record.no_duplicate_name else 'allowed'}**.", 3
        )
        await self.view.refresh_view()

        await self.view.record.confirm_all_scrims(self.ctx, no_duplicate_name=self.view.record.no_duplicate_name)


class DeleteReject(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()
        self.view.record.autodelete_rejects = not self.view.record.autodelete_rejects
        await self.ctx.success(
            f"Rejected registrations will **{'be' if self.view.record.autodelete_rejects else 'not be'}** deleted automatically.",
            3,
        )
        await self.view.refresh_view()
        await self.view.record.confirm_all_scrims(self.ctx, autodelete_rejects=self.view.record.autodelete_rejects)


class DeleteLate(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        self.view.record.autodelete_extras = not self.view.record.autodelete_extras
        await self.ctx.success(
            f"Late/Extra registration messages will **{'be' if self.view.record.autodelete_extras else 'not be'}** deleted automatically.",
            3,
        )
        await self.view.refresh_view()
        await self.view.record.confirm_all_scrims(self.ctx, autodelete_extras=self.view.record.autodelete_extras)


class SlotlistStart(ScrimsButton):
    def __init__(self, ctx: Context, letter: str):
        super().__init__(emoji=ri(letter))
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        m = await self.ctx.success(
            f"From which slot number do you want to start the slotlist? (Enter a number between 1 and {self.view.record.total_slots})"
        )
        self.view.record.start_from = await inputs.integer_input(
            self.ctx, delete_after=True, limits=(1, self.view.record.total_slots)
        )

        await self.ctx.safe_delete(m)
        await self.view.refresh_view()
        await self.view.record.confirm_all_scrims(self.ctx, start_from=self.view.record.start_from)


class Discard(ScrimsButton):
    def __init__(self, ctx: Context, label="Back", row: int = None):
        super().__init__(style=discord.ButtonStyle.red, label=label, row=row)
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        from .main import ScrimsMain as SM

        self.view.stop()
        v = SM(self.ctx)
        v.message = await self.view.message.edit(embed=await v.initial_embed(), view=v)


class DeleteScrim(ScrimsButton):
    def __init__(self, ctx: Context):
        super().__init__(emoji=emote.trash, label="Delete")
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        prompt = await self.ctx.prompt(
            f"{self.view.record} will be permanently deleted. This action is irreversible.",
            title="Are you sure you want to continue?",
        )
        if not prompt:
            return await self.ctx.simple("OK! Not deleting.", 4)

        await self.view.record.full_delete()
        await self.ctx.success(f"{self.view.record} has been deleted.", 4)

        from .main import ScrimsMain as SM

        self.view.stop()
        v = SM(self.ctx)
        v.message = await self.view.message.edit(embed=await v.initial_embed(), view=v)


class SaveScrim(ScrimsButton):
    def __init__(self, ctx: Context):
        super().__init__(style=discord.ButtonStyle.green, label="Save Scrim", disabled=True)
        self.ctx = ctx

    async def callback(self, interaction: Interaction):
        await interaction.response.defer()

        self.ctx.bot.loop.create_task(self.view.record.setup_logs())

        self.view.record.autoclean_time = self.ctx.bot.current_time.replace(
            hour=4, minute=0, second=0, microsecond=0
        ) + timedelta(days=1)

        await self.view.record.save()

        await self.ctx.bot.reminders.create_timer(self.view.record.open_time, "scrim_open", scrim_id=self.view.record.id)

        await self.ctx.bot.reminders.create_timer(
            self.view.record.autoclean_time, "autoclean", scrim_id=self.view.record.id
        )

        self.view.stop()
        await self.ctx.success(f"Scrim was successfully created. (Registration: {dt(self.view.record.open_time)})", 6)

        from .main import ScrimsMain

        view = ScrimsMain(self.ctx)
        view.message = await self.view.message.edit(embed=await view.initial_embed(), view=view)


#!add option to add this scrim to cancel claim
