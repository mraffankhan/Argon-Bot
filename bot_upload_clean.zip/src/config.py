# for tortoise-orm
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Force Tortoise ORM to use aiomysql instead of asyncmy (fixes connection reset errors on some Pterodactyl panels)
sys.modules['asyncmy'] = None

# Create custom SSL context to bypass verification (needed for some environments)
import ssl
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

TORTOISE = {
    "connections": {
        "default": {
            "engine": "tortoise.backends.mysql",
            "credentials": {
                "database": "s1336_Argon",
                "host": "db.mum-1.endercloud.in",
                "password": "H!0PZBvdZAb58+HZ+^QG.850",
                "port": 3306,
                "user": "u1336_EGjFu4y4L9",
                "ssl": ctx,
                "minsize": 10,
                "maxsize": 30,
                "connect_timeout": 5,
                "autocommit": True,
            },
        }
    },
    "apps": {
        "models": {
            "models": ["models", "aerich.models"],
            "default_connection": "default",
        },
    },
}

EXTENSIONS = (
    "jishaku",
    "cogs.esports",
    "cogs.events",
    "cogs.mod",
    "cogs.premium",
    "cogs.argonmisc",
    "cogs.reminder",
    "cogs.utility",
    "cogs.ticket",
    "cogs.bug",
)

DISCORD_TOKEN = "MTQ3MDAzMTA5NzM1NzE0MDA2Mw.G8WWf9.ySGN8l1tlwILk39Z4CtCu5MNHfN1VOd0iQdg8Q"
PRIVATE_BOT_TOKEN = "MTQ3NTI5NjMyODA0NDExODE2OQ.GILJ3d.fDZecdN3LPv4TtRc4mQ8c5ArdvDyhg_xfdXbYw"

PRIVATE_BOT_EXTENSIONS = (
    "jishaku",
    "cogs.mod",
    "cogs.antinuke",
    "cogs.private_welcome",
    "cogs.private_help",
)

COLOR = 0xab48d1

FOOTER = "Made with ❤️ By RAVONIX HQ"

PREFIX = "a"

DEVS = (1449081308616720628,)  # Bot owner IDs

SERVER_LINK = "https://discord.gg/ZT4KXFK3RD"

SERVER_ID = 859292908304859156  # REPLACE WITH YOUR SUPPORT SERVER ID

# 
BOT_INVITE = "https://discord.com/oauth2/authorize?client_id=1470031097357140063&permissions=8&integration_type=0&scope=applications.commands+bot+"

WEBSITE = "https://genzconnect.pro"

REPOSITORY = ""

DEVS = (1449081308616720628,)

# FastAPI OCR Service (for screenshot verification)
FASTAPI_URL = ""  # Leave empty if not using screenshot verification
FASTAPI_KEY = ""  # Leave empty if not using screenshot verification

# Socket/WebSocket Configuration
SOCKET_URL = ""  # Leave empty if not using socket connections
SOCKET_AUTH = ""  # Leave empty if not using socket connections

# Discord IDs and Roles
SERVER_ID = 859292908304859156  # Main server ID
VOTER_ROLE = 0  # Role ID for voters
PREMIUM_ROLE = 0  # Role ID for premium users
PREMIUM_AVATAR = "https://cdn.discordapp.com/emojis/0.png"  # Avatar for premium logs

# Emojis
PRIME_EMOJI = "⭐"  # Premium emoji

# Links
PRO_LINK = SERVER_LINK  # Argon Premium invite link

# LOGS
PUBLIC_LOG = ""  # Webhook URL for public logs
SHARD_LOG = ""
ERROR_LOG = ""

